import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';

Color CouleurPrincipale = Colors.green;

TextStyle TitreStyle = GoogleFonts.abel(fontSize: 24, color: Colors.black);

TextStyle TitreStyleWhite = GoogleFonts.abel(fontSize: 24, color: Colors.white);

TextStyle SousTStyle =
    GoogleFonts.actor(fontSize: 15, color: Colors.green.shade400);

TextStyle DescStyle = GoogleFonts.abel(fontSize: 18, color: Colors.black);

String Adress_IP = '192.168.1.64';
